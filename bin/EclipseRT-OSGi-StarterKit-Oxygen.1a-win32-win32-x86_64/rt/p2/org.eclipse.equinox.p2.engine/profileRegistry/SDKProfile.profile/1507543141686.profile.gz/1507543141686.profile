<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='SDKProfile' timestamp='1507543141686'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt'/>
  </properties>
</profile>
