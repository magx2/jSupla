<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='SDKProfile' timestamp='1507543142845'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.cache' value='/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt'/>
    <property name='eclipse.touchpoint.launcherName' value='rt'/>
  </properties>
  <units size='89'>
    <unit id='a.jre.javase' version='1.6.0' singleton='false'>
      <provides size='171'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='1.6.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activity' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.attachment' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.http' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.wsaddressing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.ORBPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.TypeCodePackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextExtPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Messaging' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor.ORBInitInfoPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.CurrentPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAManagerPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.ServantLocatorPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.SendingContext' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.stub.java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.0.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.1.0'/>
        <provided namespace='osgi.ee' name='OSGi/Minimum' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JRE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.0.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.1.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.2.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.3.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.4.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.5.0'/>
        <provided namespace='osgi.ee' name='JavaSE' version='1.6.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='config.a.jre.javase' version='1.6.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' version='1.6.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='install'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.codec' version='1.9.0.v20170208-1614' singleton='false'>
      <update id='org.apache.commons.codec' range='[0.0.0,1.9.0.v20170208-1614)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Codec'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Apache Commons Codec package contains simple encoder and decoders for     various formats such as Base64 and Hexadecimal.  In addition to these     widely used encoders and decoders, the codec package also maintains a     collection of phonetic encoding utilities.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://commons.apache.org/proper/commons-codec/'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.commons.codec'/>
        <property name='maven-version' value='1.9.0-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' version='1.9.0.v20170208-1614'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.codec' version='1.9.0.v20170208-1614'/>
        <provided namespace='java.package' name='org.apache.commons.codec' version='1.9.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.binary' version='1.9.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.digest' version='1.9.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language' version='1.9.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language.bm' version='1.9.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.net' version='1.9.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.apache.commons.codec' range='[1.9.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='[1.9.0,2.0.0)' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.codec' version='1.9.0.v20170208-1614'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.codec&#xA;Bundle-Version: 1.9.0.v20170208-1614
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.logging' version='1.1.1.v201101211721' singleton='false'>
      <update id='org.apache.commons.logging' range='[0.0.0,1.1.1.v201101211721)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='Apache Commons Logging Plug-in'/>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='iplog.bug_id' value='1907'/>
        <property name='iplog.contact.name' value='Chris Aniszczyk'/>
        <property name='iplog.contact.email' value='zx@code9.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' version='1.1.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.logging' version='1.1.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.1.1'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.1.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.logging' version='1.1.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.logging&#xA;Bundle-Version: 1.1.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.command' version='0.10.0.v201209301215' singleton='false'>
      <update id='org.apache.felix.gogo.command' range='[0.0.0,0.10.0.v201209301215)' severity='0'/>
      <properties size='10'>
        <property name='df_LT.pluginName' value='Apache Felix Gogo Command'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.description' value='Provides basic shell commands for Gogo.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='6793'/>
        <property name='iplog.contact.name' value='Lazar Kirchev'/>
        <property name='iplog.contact.email' value='l.kirchev@sap.com'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.apache.org/'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' version='0.10.0.v201209301215'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.command' version='0.10.0.v201209301215'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='0.10.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.5.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.command' version='0.10.0.v201209301215'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.command&#xA;Bundle-Version: 0.10.0.v201209301215
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.runtime' version='0.10.0.v201209301036' singleton='false'>
      <update id='org.apache.felix.gogo.runtime' range='[0.0.0,0.10.0.v201209301036)' severity='0'/>
      <properties size='10'>
        <property name='df_LT.pluginName' value='Apache Felix Gogo Runtime'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Felix Gogo Subproject'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='6793'/>
        <property name='iplog.contact.name' value='Lazar Kirchev'/>
        <property name='iplog.contact.email' value='l.kirchev@sap.com'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.apache.org/'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' version='0.10.0.v201209301036'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.runtime' version='0.10.0.v201209301036'/>
        <provided namespace='java.package' name='org.apache.felix.service.command' version='0.10.0'/>
        <provided namespace='java.package' name='org.apache.felix.gogo.api' version='0.10.0'/>
        <provided namespace='java.package' name='org.apache.felix.service.threadio' version='0.10.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.apache.felix.gogo.api' range='0.10.0'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='0.10.0'/>
        <required namespace='java.package' name='org.apache.felix.service.threadio' range='0.10.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.runtime' version='0.10.0.v201209301036'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.runtime&#xA;Bundle-Version: 0.10.0.v201209301036
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.gogo.shell' version='0.10.0.v201212101605' singleton='false'>
      <update id='org.apache.felix.gogo.shell' range='[0.0.0,0.10.0.v201212101605)' severity='0'/>
      <properties size='10'>
        <property name='df_LT.pluginName' value='Apache Felix Gogo Shell'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.description' value='Apache Felix Gogo Subproject'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='6793'/>
        <property name='iplog.contact.name' value='Lazar Kirchev'/>
        <property name='iplog.contact.email' value='l.kirchev@sap.com'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.apache.org/'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' version='0.10.0.v201212101605'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.gogo.shell' version='0.10.0.v201212101605'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='0.10.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.gogo.shell' version='0.10.0.v201212101605'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.gogo.shell&#xA;Bundle-Version: 0.10.0.v201212101605
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.felix.scr' version='2.0.10.v20170501-2007' singleton='false'>
      <update id='org.apache.felix.scr' range='[0.0.0,2.0.10.v20170501-2007)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Felix Declarative Services'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='Implementation of the Declarative Services specification 1.3'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://felix.apache.org/site/apache-felix-service-component-runtime.html'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.felix.scr'/>
        <property name='maven-version' value='2.0.10-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' version='2.0.10.v20170501-2007'/>
        <provided namespace='osgi.bundle' name='org.apache.felix.scr' version='2.0.10.v20170501-2007'/>
        <provided namespace='java.package' name='org.apache.felix.scr.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.apache.felix.scr.info' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='java.package' name='org.apache.felix.service.command' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.felix.shell' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.dto' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='[1.8.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.1.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.5.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.apache.felix.scr.info' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.0.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.felix.scr' version='2.0.10.v20170501-2007'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.felix.scr&#xA;Bundle-Version: 2.0.10.v20170501-2007
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.httpcomponents.httpclient' version='4.5.2.v20170210-0925' singleton='false'>
      <update id='org.apache.httpcomponents.httpclient' range='[0.0.0,4.5.2.v20170210-0925)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache HttpClient'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.httpcomponents.httpclient'/>
        <property name='maven-version' value='4.5.2-SNAPSHOT'/>
      </properties>
      <provides size='35'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpclient' version='4.5.2.v20170210-0925'/>
        <provided namespace='osgi.bundle' name='org.apache.httpcomponents.httpclient' version='4.5.2.v20170210-0925'/>
        <provided namespace='java.package' name='org.apache.http.auth' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.auth.params' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.cache' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.config' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.entity' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.fluent' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.methods' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.params' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.protocol' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.client.utils' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn.params' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn.routing' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn.scheme' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn.socket' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn.ssl' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.conn.util' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.cookie' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.cookie.params' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.entity.mime' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.entity.mime.content' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.auth' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.client' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.client.cache' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.client.cache.ehcache' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.client.cache.memcached' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.conn' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.conn.tsccm' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.cookie' version='4.5.2'/>
        <provided namespace='java.package' name='org.apache.http.impl.execchain' version='4.5.2'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='58'>
        <required namespace='java.package' name='org.apache.http.auth' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.auth.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.cache' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.config' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.entity' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.methods' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.protocol' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.client.utils' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.routing' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.scheme' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.socket' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.ssl' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.conn.util' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.cookie' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.cookie.params' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.entity.mime.content' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.auth' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client.cache' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.conn' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.cookie' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.execchain' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.concurrent' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.config' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.entity' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.impl' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.entity' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.io' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.io' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.message' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.params' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.pool' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.protocol' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.ssl' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.http.util' range='[4.4.6,4.5.0)'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='1.9.0'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='1.1.1'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.directory' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.naming.ldap' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.security.auth.x500' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='net.sf.ehcache' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='net.spy.memcached' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.ietf.jgss' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.client.fluent' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.entity.mime' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client.cache.ehcache' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.client.cache.memcached' range='[4.5.0,5.0.0)'/>
        <required namespace='java.package' name='org.apache.http.impl.conn.tsccm' range='[4.5.0,5.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.httpcomponents.httpclient' version='4.5.2.v20170210-0925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.httpcomponents.httpclient&#xA;Bundle-Version: 4.5.2.v20170210-0925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.httpcomponents.httpcore' version='4.4.6.v20170210-0925' singleton='false'>
      <update id='org.apache.httpcomponents.httpcore' range='[0.0.0,4.4.6.v20170210-0925)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache HttpCore'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.apache.httpcomponents.httpcore'/>
        <property name='maven-version' value='4.4.6-SNAPSHOT'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpcore' version='4.4.6.v20170210-0925'/>
        <provided namespace='osgi.bundle' name='org.apache.httpcomponents.httpcore' version='4.4.6.v20170210-0925'/>
        <provided namespace='java.package' name='org.apache.http' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.annotation' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.concurrent' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.config' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.entity' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.impl' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.impl.bootstrap' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.impl.entity' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.impl.io' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.impl.pool' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.io' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.message' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.params' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.pool' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.protocol' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.ssl' version='4.4.6'/>
        <provided namespace='java.package' name='org.apache.http.util' version='4.4.6'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.concurrent' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.config' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.entity' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.impl' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.impl.entity' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.impl.io' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.io' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.message' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.params' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.pool' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.protocol' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.apache.http.util' range='[4.4.0,5.0.0)' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.httpcomponents.httpcore' version='4.4.6.v20170210-0925'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.httpcomponents.httpcore&#xA;Bundle-Version: 4.4.6.v20170210-0925
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.9.1.v20170714-0547'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.9.1.v20170714-0547)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.core'/>
        <property name='maven-artifactId' value='org.eclipse.core.jobs'/>
        <property name='maven-version' value='3.9.1-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.9.1.v20170714-0547'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.9.1.v20170714-0547'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.8.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.9.1.v20170714-0547'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.9.1.v20170714-0547
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf' version='3.8.0.v20170104-0657'>
      <update id='org.eclipse.ecf' range='[0.0.0,3.8.0.v20170104-0657)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Core API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf'/>
        <property name='maven-version' value='3.8.0-SNAPSHOT'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' version='3.8.0.v20170104-0657'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf' version='3.8.0.v20170104-0657'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core' version='3.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.events' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.jobs' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.provider' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.security' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.start' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.status' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.user' version='3.1.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.5.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util.reflection' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.identity' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.concurrent.future' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf' version='3.8.0.v20170104-0657'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf;singleton:=true&#xA;Bundle-Version: 3.8.0.v20170104-0657
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.core.feature.feature.group' version='1.4.0.v20170516-2248' singleton='false'>
      <update id='org.eclipse.ecf.core.feature.feature.group' range='[0.0.0,1.4.0.v20170516-2248)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Core Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the ECF core (org.eclipse.ecf) and ECF identity (org.eclipse.ecf.identity) bundles.  These two bundles are required for all other parts of ECF.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.core.feature'/>
        <property name='maven-version' value='1.4.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.feature.feature.group' version='1.4.0.v20170516-2248'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.6.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.5.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' range='[1.0.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.5.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='[3.8.0.v20170104-0657,3.8.0.v20170104-0657]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='[3.8.0.v20161203-2153,3.8.0.v20161203-2153]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.feature.feature.jar' range='[1.4.0.v20170516-2248,1.4.0.v20170516-2248]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2009 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.core.feature.feature.jar' version='1.4.0.v20170516-2248'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Core Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the ECF core (org.eclipse.ecf) and ECF identity (org.eclipse.ecf.identity) bundles.  These two bundles are required for all other parts of ECF.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.core.feature'/>
        <property name='maven-version' value='1.4.0-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.feature.feature.jar' version='1.4.0.v20170516-2248'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.ecf.core.feature' version='1.4.0.v20170516-2248'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.ecf.core.feature' version='1.4.0.v20170516-2248'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2009 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.core.ssl.feature.feature.group' version='1.1.0.v20170110-1317' singleton='false'>
      <update id='org.eclipse.ecf.core.ssl.feature.feature.group' range='[0.0.0,1.1.0.v20170110-1317)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Core SSL Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the ECF core SSL fragment.  On Equinox-based frameworks, this fragment exposes the Equinox TrustManager to ECF FileTransfer and other ECF-based communications.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.core.ssl.feature'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.ssl.feature.feature.group' version='1.1.0.v20170110-1317'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' range='[1.2.0.v20160817-1024,1.2.0.v20160817-1024]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.ssl.feature.feature.jar' range='[1.1.0.v20170110-1317,1.1.0.v20170110-1317]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2009 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.core.ssl.feature.feature.jar' version='1.1.0.v20170110-1317'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Core SSL Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the ECF core SSL fragment.  On Equinox-based frameworks, this fragment exposes the Equinox TrustManager to ECF FileTransfer and other ECF-based communications.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.core.ssl.feature'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.ssl.feature.feature.jar' version='1.1.0.v20170110-1317'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.ecf.core.ssl.feature' version='1.1.0.v20170110-1317'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.ecf.core.ssl.feature' version='1.1.0.v20170110-1317'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2009 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer' version='5.0.0.v20160817-1024'>
      <update id='org.eclipse.ecf.filetransfer' range='[0.0.0,5.0.0.v20160817-1024)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer'/>
        <property name='maven-version' value='5.0.0-SNAPSHOT'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' version='5.0.0.v20160817-1024'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' version='5.0.0.v20160817-1024'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socket' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socketfactory' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.identity' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.service' version='5.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.filetransfer' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.filetransfer' version='5.0.0.v20160817-1024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.filetransfer;singleton:=true&#xA;Bundle-Version: 5.0.0.v20160817-1024
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.feature.feature.group' version='3.13.7.v20170516-2248' singleton='false'>
      <update id='org.eclipse.ecf.filetransfer.feature.feature.group' range='[0.0.0,3.13.7.v20170516-2248)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Filetransfer Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the ECF Filetransfer API bundle.  This API is used&#xA;by the Eclipse platform to support P2 filetransfer and is required for any of the ECF FileTransfer providers.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.feature'/>
        <property name='maven-version' value='3.13.7-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.feature.group' version='3.13.7.v20170516-2248'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' range='[5.0.0.v20160817-1024,5.0.0.v20160817-1024]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' range='[3.2.300.v20161203-1840,3.2.300.v20161203-1840]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.feature.jar' range='[3.13.7.v20170516-2248,3.13.7.v20170516-2248]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004, 2007 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.feature.feature.jar' version='3.13.7.v20170516-2248'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Filetransfer Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the ECF Filetransfer API bundle.  This API is used&#xA;by the Eclipse platform to support P2 filetransfer and is required for any of the ECF FileTransfer providers.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.feature'/>
        <property name='maven-version' value='3.13.7-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.feature.jar' version='3.13.7.v20170516-2248'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.ecf.filetransfer.feature' version='3.13.7.v20170516-2248'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.ecf.filetransfer.feature' version='3.13.7.v20170516-2248'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2004, 2007 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.group' version='3.13.7.v20170516-2248' singleton='false'>
      <update id='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.group' range='[0.0.0,3.13.7.v20170516-2248)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Httpclient4 Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the Apache HttpComponents/HttpClient4-based FileTransfer provider used by the Eclipse platform to support P2 filetransfer.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.httpclient4.feature'/>
        <property name='maven-version' value='3.13.7-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.group' version='3.13.7.v20170516-2248'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.feature.group' range='[3.9.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient4' range='[1.1.200.v20170314-0133,1.1.200.v20170314-0133]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' range='[1.9.0.v20170208-1614,1.9.0.v20170208-1614]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.1.1.v201101211721,1.1.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpclient' range='[4.5.2.v20170210-0925,4.5.2.v20170210-0925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.httpcomponents.httpcore' range='[4.4.6.v20170210-0925,4.4.6.v20170210-0925]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.jar' range='[3.13.7.v20170516-2248,3.13.7.v20170516-2248]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        Copyright (c) 2011 Composent, Inc. and others. All rights reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.jar' version='3.13.7.v20170516-2248'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Httpclient4 Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the Apache HttpComponents/HttpClient4-based FileTransfer provider used by the Eclipse platform to support P2 filetransfer.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.httpclient4.feature'/>
        <property name='maven-version' value='3.13.7-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.jar' version='3.13.7.v20170516-2248'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.ecf.filetransfer.httpclient4.feature' version='3.13.7.v20170516-2248'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.ecf.filetransfer.httpclient4.feature' version='3.13.7.v20170516-2248'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        Copyright (c) 2011 Composent, Inc. and others. All rights reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.group' version='1.1.0.v20170110-1317' singleton='false'>
      <update id='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.group' range='[0.0.0,1.1.0.v20170110-1317)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Httpclient4 Filetransfer SSL Provider'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the SSL support for the Apache HttpComponents/HttpClient4-based FileTransfer provider used by the Eclipse platform to support P2 filetransfer.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.group' version='1.1.0.v20170110-1317'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.ssl.feature.feature.group' range='[1.0.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl' range='[1.1.0.v20160817-1024,1.1.0.v20160817-1024]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.jar' range='[1.1.0.v20170110-1317,1.1.0.v20170110-1317]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        Copyright (c) 2014 Composent, Inc. and others. All rights reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.jar' version='1.1.0.v20170110-1317'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Httpclient4 Filetransfer SSL Provider'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the SSL support for the Apache HttpComponents/HttpClient4-based FileTransfer provider used by the Eclipse platform to support P2 filetransfer.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.jar' version='1.1.0.v20170110-1317'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature' version='1.1.0.v20170110-1317'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature' version='1.1.0.v20170110-1317'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        Copyright (c) 2014 Composent, Inc. and others. All rights reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.ssl.feature.feature.group' version='1.1.0.v20170110-1317' singleton='false'>
      <update id='org.eclipse.ecf.filetransfer.ssl.feature.feature.group' range='[0.0.0,1.1.0.v20170110-1317)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Filetransfer SSL Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the SSL support for the ECF FileTransfer API used by the Eclipse platform to support P2 filetransfer.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.ssl.feature'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.ssl.feature.feature.group' version='1.1.0.v20170110-1317'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.feature.group' range='[3.9.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.ssl.feature.feature.group' range='[1.0.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' range='[1.0.0.v20160817-1024,1.0.0.v20160817-1024]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.ssl.feature.feature.jar' range='[1.1.0.v20170110-1317,1.1.0.v20170110-1317]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2014 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer.ssl.feature.feature.jar' version='1.1.0.v20170110-1317'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='ECF Filetransfer SSL Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='This feature provides the SSL support for the ECF FileTransfer API used by the Eclipse platform to support P2 filetransfer.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/ecf'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.filetransfer.ssl.feature'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.ssl.feature.feature.jar' version='1.1.0.v20170110-1317'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.ecf.filetransfer.ssl.feature' version='1.1.0.v20170110-1317'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.ecf.filetransfer.ssl.feature' version='1.1.0.v20170110-1317'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        Copyright (c) 2014 Composent, Inc. and others. All rights&#xA;reserved.&#xA;This program and the accompanying materials are made available&#xA;under the terms of the Eclipse Public License v1.0 which accompanies&#xA;this distribution, and is available at &#xA;http://www.eclipse.org/legal/epl-v10.html&#xA; &#xA;Contributors: Composent, Inc. - initial API and implementation
      </copyright>
    </unit>
    <unit id='org.eclipse.ecf.identity' version='3.8.0.v20161203-2153'>
      <update id='org.eclipse.ecf.identity' range='[0.0.0,3.8.0.v20161203-2153)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Identity Core API'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.identity'/>
        <property name='maven-version' value='3.8.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' version='3.8.0.v20161203-2153'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.identity' version='3.8.0.v20161203-2153'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.identity' version='3.3.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core.identity' version='3.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.identity' version='3.8.0.v20161203-2153'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.identity;singleton:=true&#xA;Bundle-Version: 3.8.0.v20161203-2153
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer' version='3.2.300.v20161203-1840'>
      <update id='org.eclipse.ecf.provider.filetransfer' range='[0.0.0,3.2.300.v20161203-1840)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.provider.filetransfer'/>
        <property name='maven-version' value='3.2.300-SNAPSHOT'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' version='3.2.300.v20161203-1840'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' version='3.2.300.v20161203-1840'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.browse' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.identity' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.outgoing' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.retrieve' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.util' version='3.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.net.proxy' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer' version='3.2.300.v20161203-1840'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer;singleton:=true&#xA;Bundle-Version: 3.2.300.v20161203-1840
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.httpclient4' version='1.1.200.v20170314-0133'>
      <update id='org.eclipse.ecf.provider.filetransfer.httpclient4' range='[0.0.0,1.1.200.v20170314-0133)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF HttpComponents Filetransfer Provider'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.provider.filetransfer.httpclient4'/>
        <property name='maven-version' value='1.1.200-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient4' version='1.1.200.v20170314-0133'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient4' version='1.1.200.v20170314-0133'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer.httpclient4' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.httpclient4' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='32'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.http' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.auth' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.client' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.client.methods' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.client.protocol' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.conn' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.conn.params' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.conn.scheme' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.conn.ssl' range='4.3.6'/>
        <required namespace='java.package' name='org.apache.http.conn.util' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.entity' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.impl' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.impl.client' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.impl.conn' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.impl.cookie' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.impl.entity' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.impl.io' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.io' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.message' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.params' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.protocol' range='4.1.0'/>
        <required namespace='java.package' name='org.apache.http.util' range='4.1.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.httpclient4' version='1.1.200.v20170314-0133'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.httpclient4;singleton:=true&#xA;Bundle-Version: 1.1.200.v20170314-0133
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl' version='1.1.0.v20160817-1024' singleton='false'>
      <update id='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl' range='[0.0.0,1.1.0.v20160817-1024)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer HttpComponents SSL Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl' version='1.1.0.v20160817-1024'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl' version='1.1.0.v20160817-1024'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf.provider.filetransfer.httpclient4' version='1.1.0.v20160817-1024'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient4' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.httpclient4.ssl' version='1.1.0.v20160817-1024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.httpclient4.ssl&#xA;Bundle-Version: 1.1.0.v20160817-1024&#xA;Fragment-Host: org.eclipse.ecf.provider.filetransfer.httpclient4;bundle-version=&quot;1.0.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20160817-1024' singleton='false'>
      <update id='org.eclipse.ecf.provider.filetransfer.ssl' range='[0.0.0,1.0.0.v20160817-1024)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF Filetransfer SSL Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.provider.filetransfer.ssl'/>
        <property name='maven-version' value='1.0.0-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20160817-1024'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20160817-1024'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf.provider.filetransfer' version='1.0.0.v20160817-1024'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='2.0.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20160817-1024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.ssl&#xA;Bundle-Version: 1.0.0.v20160817-1024&#xA;Fragment-Host: org.eclipse.ecf.provider.filetransfer;bundle-version=&quot;2.0.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.ssl' version='1.2.0.v20160817-1024' singleton='false'>
      <update id='org.eclipse.ecf.ssl' range='[0.0.0,1.2.0.v20160817-1024)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='df_LT.plugin.name' value='ECF SSL Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.ecf'/>
        <property name='maven-artifactId' value='org.eclipse.ecf.ssl'/>
        <property name='maven-version' value='1.2.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' version='1.2.0.v20160817-1024'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.ssl' version='1.2.0.v20160817-1024'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.ssl' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf' version='1.2.0.v20160817-1024'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='java.package' name='javax.net' range='0.0.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.ssl' version='1.2.0.v20160817-1024'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ecf.ssl&#xA;Bundle-Version: 1.2.0.v20160817-1024&#xA;Fragment-Host: org.eclipse.ecf
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.3.400.v20150715-1528'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.3.400.v20150715-1528)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.app'/>
        <property name='maven-version' value='1.3.400-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.3.400.v20150715-1528'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.3.400.v20150715-1528'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.3.400.v20150715-1528'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.3.400.v20150715-1528
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.9.0.v20170207-1454'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.9.0.v20170207-1454)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.common'/>
        <property name='maven-version' value='3.9.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.9.0.v20170207-1454'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.9.0.v20170207-1454'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.5.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='java.package' name='org.eclipse.equinox.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.urlconversion' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.9.0.v20170207-1454'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.9.0.v20170207-1454
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.concurrent' version='1.1.0.v20130327-1442' singleton='false'>
      <update id='org.eclipse.equinox.concurrent' range='[0.0.0,1.1.0.v20130327-1442)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginProvider' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Concurrent API'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%pluginProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.concurrent'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' version='1.1.0.v20130327-1442'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.concurrent' version='1.1.0.v20130327-1442'/>
        <provided namespace='java.package' name='org.eclipse.equinox.concurrent.future' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='3.4.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.concurrent' version='1.1.0.v20130327-1442'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.concurrent&#xA;Bundle-Version: 1.1.0.v20130327-1442
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.console' version='1.1.300.v20170512-2111' singleton='false'>
      <update id='org.eclipse.equinox.console' range='[0.0.0,1.1.300.v20170512-2111)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Console plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.console'/>
        <property name='maven-version' value='1.1.300-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' version='1.1.300.v20170512-2111'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.console' version='1.1.300.v20170512-2111'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.common.terminal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.console.completion.common' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='osgi.bundle' name='org.apache.felix.gogo.runtime' range='0.10.0'/>
        <required namespace='osgi.bundle' name='org.apache.felix.gogo.shell' range='0.10.0'/>
        <required namespace='java.package' name='org.apache.felix.service.command' range='0.8.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.report.resolution' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.hooks.resolver' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.4.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.permissionadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.console' version='1.1.300.v20170512-2111'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.console&#xA;Bundle-Version: 1.1.300.v20170512-2111
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.core.feature.feature.group' version='1.4.1.v20170928-1321' singleton='false'>
      <update id='org.eclipse.equinox.core.feature.feature.group' range='[0.0.0,1.4.1.v20170928-1321)' severity='0'/>
      <properties size='10'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.equinox.feature'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.core.feature'/>
        <property name='maven-version' value='1.4.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 EclipseSource and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.featureName' value='Equinox Core Function'/>
        <property name='df_LT.providerName' value='Eclipse Equinox Project'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.core.feature.feature.group' version='1.4.1.v20170928-1321'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.12.50.v20170928-1321,3.12.50.v20170928-1321]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.6.0.v20170228-1906,3.6.0.v20170228-1906]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.4.0.v20170111-1608,3.4.0.v20170111-1608]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.9.0.v20170207-1454,3.9.0.v20170207-1454]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' range='[1.5.0.v20170307-1429,1.5.0.v20170307-1429]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' range='[1.0.500.v20130404-1337,1.0.500.v20130404-1337]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.7.0.v20170222-1344,3.7.0.v20170222-1344]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.2.0.v20170110-1705,1.2.0.v20170110-1705]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.3.400.v20150715-1528,1.3.400.v20150715-1528]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' range='[1.1.0.v20170516-1513,1.1.0.v20170516-1513]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.console' range='[1.1.300.v20170512-2111,1.1.300.v20170512-2111]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.command' range='[0.10.0.v201209301215,0.10.0.v201209301215]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.runtime' range='[0.10.0.v201209301036,0.10.0.v201209301036]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.gogo.shell' range='[0.10.0.v201212101605,0.10.0.v201212101605]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.felix.scr' range='[2.0.10.v20170501-2007,2.0.10.v20170501-2007]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.core.feature.feature.jar' range='[1.4.1.v20170928-1321,1.4.1.v20170928-1321]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.core.feature.feature.jar' version='1.4.1.v20170928-1321'>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 EclipseSource and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.featureName' value='Equinox Core Function'/>
        <property name='df_LT.providerName' value='Eclipse Equinox Project'/>
        <property name='maven-groupId' value='org.eclipse.equinox.feature'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.core.feature'/>
        <property name='maven-version' value='1.4.1-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.core.feature.feature.jar' version='1.4.1.v20170928-1321'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.equinox.core.feature' version='1.4.1.v20170928-1321'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.equinox.core.feature' version='1.4.1.v20170928-1321'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.ds' version='1.5.0.v20170307-1429'>
      <update id='org.eclipse.equinox.ds' range='[0.0.0,1.5.0.v20170307-1429)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Declarative Services'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='This bundle provides support for OSGi Declarative Services'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.ds'/>
        <property name='maven-version' value='1.5.0-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
        <provided namespace='osgi.extender' name='osgi.component' version='1.3.0'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.ds' version='1.5.0.v20170307-1429'/>
        <provided namespace='java.package' name='org.apache.felix.scr' version='1.6.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' version='1.5.0.v20170307-1429'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.apache.felix.scr' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.component' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.ds' version='1.5.0.v20170307-1429'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='3'>
          <instruction key='unconfigure'>
            setProgramProperty(propName:equinox.use.ds, propValue:);setProgramProperty(propName:ds.delayed.keepInstances, propValue:);
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.ds;singleton:=true&#xA;Bundle-Version: 1.5.0.v20170307-1429
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:equinox.use.ds, propValue:true);setProgramProperty(propName:ds.delayed.keepInstances, propValue:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin' version='2.0.300.v20160504-1450'>
      <update id='org.eclipse.equinox.frameworkadmin' range='[0.0.0,2.0.300.v20160504-1450)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.frameworkadmin'/>
        <property name='maven-version' value='2.0.300-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' version='2.0.300.v20160504-1450'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin' version='2.0.300.v20160504-1450'/>
        <provided namespace='java.package' name='org.eclipse.equinox.frameworkadmin' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin' version='2.0.300.v20160504-1450'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin;singleton:=true&#xA;Bundle-Version: 2.0.300.v20160504-1450
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.800.v20170524-1345'>
      <update id='org.eclipse.equinox.frameworkadmin.equinox' range='[0.0.0,1.0.800.v20170524-1345)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Framework Admin for Equinox'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.frameworkadmin.equinox'/>
        <property name='maven-version' value='1.0.800-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.800.v20170524-1345'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.800.v20170524-1345'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox.utils' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.800.v20170524-1345'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin.equinox;singleton:=true&#xA;Bundle-Version: 1.0.800.v20170524-1345
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.4.0.v20161219-1356'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.4.0.v20161219-1356)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher'/>
        <property name='maven-version' value='1.4.0-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.4.0.v20161219-1356'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.4.0.v20161219-1356'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.4.0.v20161219-1356'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.4.0.v20161219-1356
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.win32.win32.x86_64' version='1.1.550.v20170928-1359'>
      <update id='org.eclipse.equinox.launcher.win32.win32.x86_64' range='[0.0.0,1.1.550.v20170928-1359)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Launcher Win32 X86_64 Fragment'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.win32.win32.x86_64'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.launcher.win32.win32.x86_64'/>
        <property name='maven-version' value='1.1.550-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' version='1.1.550.v20170928-1359'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86_64' version='1.1.550.v20170928-1359'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.1.550.v20170928-1359'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.0.0,1.5.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.win32.win32.x86_64' version='1.1.550.v20170928-1359'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.win32.win32.x86_64;singleton:=true&#xA;Bundle-Version: 1.1.550.v20170928-1359&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.0.0,1.5.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.artifact.repository' version='1.1.650.v20170928-1405'>
      <update id='org.eclipse.equinox.p2.artifact.repository' range='[0.0.0,1.1.650.v20170928-1405)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Artifact Repository Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.artifact.repository'/>
        <property name='maven-version' value='1.1.650-SNAPSHOT'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' version='1.1.650.v20170928-1405'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' version='1.1.650.v20170928-1405'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.md5' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pack200' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.artifact.repository.processing' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='28'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.artifact.repository' version='1.1.650.v20170928-1405'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.artifact.repository;singleton:=true&#xA;Bundle-Version: 1.1.650.v20170928-1405
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.console' version='1.0.600.v20170511-1106'>
      <update id='org.eclipse.equinox.p2.console' range='[0.0.0,1.0.600.v20170511-1106)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Console'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.console'/>
        <property name='maven-version' value='1.0.600-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' version='1.0.600.v20170511-1106'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.console' version='1.0.600.v20170511-1106'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.console' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.console' version='1.0.600.v20170511-1106'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.console;singleton:=true&#xA;Bundle-Version: 1.0.600.v20170511-1106
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.4.101.v20170906-1259'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.4.101.v20170906-1259)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.core'/>
        <property name='maven-version' value='2.4.101-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.4.101.v20170906-1259'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.4.101.v20170906-1259'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.4.101.v20170906-1259'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.4.101.v20170906-1259
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core.feature.feature.group' version='1.4.1.v20170928-1405' singleton='false'>
      <update id='org.eclipse.equinox.p2.core.feature.feature.group' range='[0.0.0,1.4.1.v20170928-1405)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.core.feature'/>
        <property name='maven-version' value='1.4.1-SNAPSHOT'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010, 2013 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.featureName' value='Equinox p2, headless functionalities'/>
        <property name='df_LT.description' value='Provides a minimal headless provisioning system.'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' version='1.4.1.v20170928-1405'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='33'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.feature.feature.group' range='[1.4.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.core.ssl.feature.feature.group' range='[1.1.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.feature.feature.group' range='[3.13.7,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.feature.feature.group' range='[3.13.7,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.httpclient4.ssl.feature.feature.group' range='[1.1.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer.ssl.feature.feature.group' range='[1.1.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.1.650.v20170928-1405,1.1.650.v20170928-1405]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' range='[1.0.600.v20170511-1106,1.0.600.v20170511-1106]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.4.101.v20170906-1259,2.4.101.v20170906-1259]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.3.300.v20160504-1450,2.3.300.v20160504-1450]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.5.0.v20170319-2002,2.5.0.v20170319-2002]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.0.300.v20160504-1450,1.0.300.v20160504-1450]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.3.200.v20170511-1106,2.3.200.v20170511-1106]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.2.401.v20170906-1259,1.2.401.v20170906-1259]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.3.301.v20170906-1259,2.3.301.v20170906-1259]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.1.501.v20170906-1259,2.1.501.v20170906-1259]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' range='[1.2.200.v20170511-1216,1.2.200.v20170511-1216]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.300.v20170515-0721,2.0.300.v20170515-0721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.3.5.v201308161310,2.3.5.v201308161310]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.3.5.v201404071733,2.3.5.v201404071733]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.0.300.v20160504-1450,2.0.300.v20160504-1450]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.0.800.v20170524-1345,1.0.800.v20170524-1345]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.7.0.v20170126-2132,3.7.0.v20170126-2132]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.2.300.v20170505-1235,1.2.300.v20170505-1235]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.0.500.v20160504-1450,1.0.500.v20160504-1450]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' range='[1.1.300.v20161004-0244,1.1.300.v20161004-0244]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' range='[2.4.300.v20170511-1106,2.4.300.v20170511-1106]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.100.200.v20130327-1442,1.100.200.v20130327-1442]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.linux.x86_64' range='[1.0.100.v20170504-1307,1.0.100.v20170504-1307]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' range='[1.0.300.v20130327-1442,1.0.300.v20130327-1442]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86_64' range='[1.0.100.v20130327-1442,1.0.100.v20130327-1442]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' range='[1.5.0.v20170111-1717,1.5.0.v20170111-1717]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.jar' range='[1.4.1.v20170928-1405,1.4.1.v20170928-1405]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.core.feature.feature.jar' version='1.4.1.v20170928-1405'>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010, 2013 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.featureName' value='Equinox p2, headless functionalities'/>
        <property name='df_LT.description' value='Provides a minimal headless provisioning system.'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.core.feature'/>
        <property name='maven-version' value='1.4.1-SNAPSHOT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.jar' version='1.4.1.v20170928-1405'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.equinox.p2.core.feature' version='1.4.1.v20170928-1405'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.equinox.p2.core.feature' version='1.4.1.v20170928-1405'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.director' version='2.3.300.v20160504-1450'>
      <update id='org.eclipse.equinox.p2.director' range='[0.0.0,2.3.300.v20160504-1450)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.director'/>
        <property name='maven-version' value='2.3.300-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' version='2.3.300.v20160504-1450'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director' version='2.3.300.v20160504-1450'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.rollback' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.planner' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='[2.3.5,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.pb' range='[2.3.5,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director' version='2.3.300.v20160504-1450'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director;singleton:=true&#xA;Bundle-Version: 2.3.300.v20160504-1450
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.5.0.v20170319-2002'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.5.0.v20170319-2002)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.engine'/>
        <property name='maven-version' value='2.5.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.5.0.v20170319-2002'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.5.0.v20170319-2002'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.2.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='34'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.5.0.v20170319-2002'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.5.0.v20170319-2002
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.garbagecollector' version='1.0.300.v20160504-1450'>
      <update id='org.eclipse.equinox.p2.garbagecollector' range='[0.0.0,1.0.300.v20160504-1450)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Garbage Collector'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.garbagecollector'/>
        <property name='maven-version' value='1.0.300-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' version='1.0.300.v20160504-1450'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.garbagecollector' version='1.0.300.v20160504-1450'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.garbagecollector' version='1.0.300.v20160504-1450'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.garbagecollector;singleton:=true&#xA;Bundle-Version: 1.0.300.v20160504-1450
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.jarprocessor' version='1.0.500.v20160504-1450'>
      <update id='org.eclipse.equinox.p2.jarprocessor' range='[0.0.0,1.0.500.v20160504-1450)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning JAR Processor'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.jarprocessor'/>
        <property name='maven-version' value='1.0.500-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' version='1.0.500.v20160504-1450'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.jarprocessor' version='1.0.500.v20160504-1450'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.unsigner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.jarprocessor' version='1.0.500.v20160504-1450'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.jarprocessor;singleton:=true&#xA;Bundle-Version: 1.0.500.v20160504-1450
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.3.200.v20170511-1106'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.3.200.v20170511-1106)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.metadata'/>
        <property name='maven-version' value='2.3.200-SNAPSHOT'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.3.200.v20170511-1106'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.3.200.v20170511-1106'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.3.200.v20170511-1106'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.3.200.v20170511-1106
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.2.401.v20170906-1259'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.2.401.v20170906-1259)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.metadata.repository'/>
        <property name='maven-version' value='1.2.401-SNAPSHOT'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.2.401.v20170906-1259'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.2.401.v20170906-1259'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.tukaani.xz' range='1.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.2.401.v20170906-1259'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.2.401.v20170906-1259
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.operations' version='2.4.300.v20170511-1106'>
      <update id='org.eclipse.equinox.p2.operations' range='[0.0.0,2.4.300.v20170511-1106)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Operations API'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.operations'/>
        <property name='maven-version' value='2.4.300-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' version='2.4.300.v20170511-1106'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.operations' version='2.4.300.v20170511-1106'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.operations' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.operations' version='2.4.300.v20170511-1106'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.operations;singleton:=true&#xA;Bundle-Version: 2.4.300.v20170511-1106
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.3.301.v20170906-1259'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.3.301.v20170906-1259)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.repository'/>
        <property name='maven-version' value='2.3.301-SNAPSHOT'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.3.301.v20170906-1259'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.3.301.v20170906-1259'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.3.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.3.301.v20170906-1259'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.3.301.v20170906-1259
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.501.v20170906-1259'>
      <update id='org.eclipse.equinox.p2.touchpoint.eclipse' range='[0.0.0,2.1.501.v20170906-1259)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Eclipse Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.touchpoint.eclipse'/>
        <property name='maven-version' value='2.1.501-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.501.v20170906-1259'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.501.v20170906-1259'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse.actions' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.update' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.touchpoint.eclipse.query' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='34'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.1.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.3.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.501.v20170906-1259'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.eclipse;singleton:=true&#xA;Bundle-Version: 2.1.501.v20170906-1259
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.200.v20170511-1216'>
      <update id='org.eclipse.equinox.p2.touchpoint.natives' range='[0.0.0,1.2.200.v20170511-1216)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning Native Touchpoint'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.touchpoint.natives'/>
        <property name='maven-version' value='1.2.200-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.200.v20170511-1216'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives.actions' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.0.v20170511-1216'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.100.v20170511-1216'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.200.v20170511-1216'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.1.100.v20140523-0116'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='2.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.natives' version='1.2.200.v20170511-1216'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.natives;singleton:=true&#xA;Bundle-Version: 1.2.200.v20170511-1216
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.transport.ecf' version='1.1.300.v20161004-0244' singleton='false'>
      <update id='org.eclipse.equinox.p2.transport.ecf' range='[0.0.0,1.1.300.v20161004-0244)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Provisioning ECF based Transport'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.transport.ecf'/>
        <property name='maven-version' value='1.1.300-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' version='1.1.300.v20161004-0244'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.transport.ecf' version='1.1.300.v20161004-0244'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.transport.ecf' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='4.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='2.0.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' range='2.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.100'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.transport.ecf' version='1.1.300.v20161004-0244'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.transport.ecf&#xA;Bundle-Version: 1.1.300.v20161004-0244
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.7.0.v20170126-2132'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.7.0.v20170126-2132)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.preferences'/>
        <property name='maven-version' value='3.7.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.7.0.v20170126-2132'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.7.0.v20170126-2132'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.1,1.2.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.7.0.v20170126-2132'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.7.0.v20170126-2132
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.7.0.v20170222-1344'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.7.0.v20170222-1344)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.registry'/>
        <property name='maven-version' value='3.7.0-SNAPSHOT'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.7.0.v20170222-1344'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.7.0.v20170222-1344'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.5.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.7.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.7.0.v20170222-1344'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.7.0.v20170222-1344
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.2.300.v20170505-1235'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.2.300.v20170505-1235)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.security'/>
        <property name='maven-version' value='1.2.300-SNAPSHOT'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.2.300.v20170505-1235'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.2.300.v20170505-1235'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.2.300.v20170505-1235'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.2.300.v20170505-1235
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security.win32.x86_64' version='1.0.100.v20130327-1442'>
      <update id='org.eclipse.equinox.security.win32.x86_64' range='[0.0.0,1.0.100.v20130327-1442)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.fragmentName' value='Windows Data Protection services integration (64 bit)'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.security.win32.x86_64'/>
        <property name='maven-version' value='1.0.100-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86_64' version='1.0.100.v20130327-1442'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security.win32.x86_64' version='1.0.100.v20130327-1442'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.security' version='1.0.100.v20130327-1442'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security' range='[1.0.0,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security.win32.x86_64' version='1.0.100.v20130327-1442'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security.win32.x86_64;singleton:=true&#xA;Bundle-Version: 1.0.100.v20130327-1442&#xA;Fragment-Host: org.eclipse.equinox.security;bundle-version=&quot;[1.0.0,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.2.0.v20170110-1705'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.2.0.v20170110-1705)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator'/>
        <property name='maven-version' value='1.2.0-SNAPSHOT'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.2.0.v20170110-1705'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.2.0.v20170110-1705'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.framework.namespace' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework.wiring' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.resource' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.2.0.v20170110-1705'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.2.0.v20170110-1705
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.300.v20170515-0721'>
      <update id='org.eclipse.equinox.simpleconfigurator.manipulator' range='[0.0.0,2.0.300.v20170515-0721)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='Simple Configurator Manipulator'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.simpleconfigurator.manipulator'/>
        <property name='maven-version' value='2.0.300-SNAPSHOT'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.300.v20170515-0721'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.300.v20170515-0721'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.300.v20170515-0721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator.manipulator;singleton:=true&#xA;Bundle-Version: 2.0.300.v20170515-0721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.util' version='1.0.500.v20130404-1337' singleton='false'>
      <update id='org.eclipse.equinox.util' range='[0.0.0,1.0.500.v20130404-1337)' severity='0'/>
      <properties size='9'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Util Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Equinox Util Bundle contains services to facilitate bundle developers in their programming, and to lighten resource usage at runtime.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.equinox'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.util'/>
        <property name='maven-version' value='1.0.500-SNAPSHOT'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' version='1.0.500.v20130404-1337'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.util' version='1.0.500.v20130404-1337'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.event' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.hash' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt.threadpool' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt.timer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.pool' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.ref' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.threadpool' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.timer' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.util' version='1.0.500.v20130404-1337'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.util&#xA;Bundle-Version: 1.0.500.v20130404-1337
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.12.50.v20170928-1321'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.12.50.v20170928-1321)' severity='0'/>
      <properties size='10'>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi'/>
        <property name='maven-version' value='3.12.50-SNAPSHOT'/>
      </properties>
      <provides size='70'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.12.50.v20170928-1321'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.12.50.v20170928-1321'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.builders' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.container.namespaces' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.framework' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.hookregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.classpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.sources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.location' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.messages' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.report.resolution' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storage.url.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.dto' version='1.8.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring.dto' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.resource.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.resolver' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.12.50.v20170928-1321'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.12.50.v20170928-1321
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.compatibility.state' version='1.1.0.v20170516-1513' singleton='false'>
      <update id='org.eclipse.osgi.compatibility.state' range='[0.0.0,1.1.0.v20170516-1513)' severity='0'/>
      <properties size='7'>
        <property name='df_LT.Bundle-Name' value='Equinox State and Resolver Compatibility Fragment'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.compatibility.state'/>
        <property name='maven-version' value='1.1.0-SNAPSHOT'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.compatibility.state' version='1.1.0.v20170516-1513'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.compatibility.state' version='1.1.0.v20170516-1513'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.osgi' version='1.1.0.v20170516-1513'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.12.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.compatibility.state' version='1.1.0.v20170516-1513'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.compatibility.state&#xA;Bundle-Version: 1.1.0.v20170516-1513&#xA;Fragment-Host: org.eclipse.osgi;bundle-version=&quot;3.12.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.6.0.v20170228-1906' singleton='false'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.6.0.v20170228-1906)' severity='0'/>
      <properties size='12'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.services'/>
        <property name='maven-version' value='3.6.0-SNAPSHOT'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.6.0.v20170228-1906'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.6.0.v20170228-1906'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.5.0'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.runtime.dto' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.3.1'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.http.context' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.runtime.dto' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.http.whiteboard' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='java.package' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.framework.dto' range='1.8.0'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.dto' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.annotations' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime.dto' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.5.0,1.6.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.component.runtime' range='[1.3.0,1.4.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.6.0.v20170228-1906'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.6.0.v20170228-1906
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.4.0.v20170111-1608' singleton='false'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.4.0.v20170111-1608)' severity='0'/>
      <properties size='12'>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
        <property name='maven-groupId' value='org.eclipse.osgi'/>
        <property name='maven-artifactId' value='org.eclipse.osgi.util'/>
        <property name='maven-version' value='3.4.0-SNAPSHOT'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.4.0.v20170111-1608'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.4.0.v20170111-1608'/>
        <provided namespace='java.package' name='org.osgi.util.function' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.promise' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.osgi.framework' range='1.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.function' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.1,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.position' range='[1.0.1,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.promise' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='org.osgi.util.xml' range='[1.0.1,1.1.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.4.0.v20170111-1608'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.4.0.v20170111-1608
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rt.osgistarterkit.product' version='4.7.1.M20171009-0410'>
      <update id='org.eclipse.rt.osgistarterkit.product' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='EclipseRT OSGi Starter Kit'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product' version='4.7.1.M20171009-0410'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.configuration' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.core.feature.feature.group' range='[1.4.1.v20170928-1321,1.4.1.v20170928-1321]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.application' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' range='[1.4.1.v20170928-1405,1.4.1.v20170928-1405]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.natives.remove(path:${installFolder}/eclipsec.exe);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;    - Content may be structured and packaged into modules to facilitate delivering,&#xA;      extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;      plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;    - Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;      in a directory named &quot;plugins&quot;.&#xA;    - A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;      Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;      Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;      numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;    - Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;      named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;    - The top-level (root) directory&#xA;    - Plug-in and Fragment directories&#xA;    - Inside Plug-ins and Fragments packaged as JARs&#xA;    - Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;    - Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature&#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;    - Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;    - Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;    - Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;    - Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;    - Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;    1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;       the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;       extending or updating the functionality of an Eclipse-based product.&#xA;    2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;       Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;    3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;       govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;       Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;       with the Specification. Such Installable Software Agreement must inform the user of the&#xA;       terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;       the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;       indication of agreement by the user, the provisioning Technology will complete installation&#xA;       of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' version='4.7.1.M20171009-0410'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' version='4.7.1.M20171009-0410'/>
        <provided namespace='toolingorg.eclipse.rt.osgistarterkit.product' name='org.eclipse.rt.osgistarterkit.product.executable' version='4.7.1.M20171009-0410'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' version='4.7.1.M20171009-0410'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64.rt' version='4.7.1.M20171009-0410' singleton='false'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64.rt' version='4.7.1.M20171009-0410'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setLauncherName(name:rt)
          </instruction>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.core' version='2.3.5.v201308161310' singleton='false'>
      <update id='org.sat4j.core' range='[0.0.0,2.3.5.v201308161310)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='SAT4J Core'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='7360'/>
        <property name='iplog.contact.name' value='Krzysztof Daniel'/>
        <property name='iplog.contact.email' value='kdaniel@redhat.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' version='2.3.5.v201308161310'/>
        <provided namespace='osgi.bundle' name='org.sat4j.core' version='2.3.5.v201308161310'/>
        <provided namespace='java.package' name='org.sat4j' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.card' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.cnf' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.learning' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.orders' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.minisat.restarts' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.opt' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.reader' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.specs' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools.encoding' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.tools.xplain' version='2.3.5.v20130525'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.core' version='2.3.5.v201308161310'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.core&#xA;Bundle-Version: 2.3.5.v201308161310
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.pb' version='2.3.5.v201404071733' singleton='false'>
      <update id='org.sat4j.pb' range='[0.0.0,2.3.5.v201404071733)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleName' value='SAT4J Pseudo'/>
        <property name='df_LT.providerName' value='Eclipse Orbit'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='iplog.bug_id' value='7360'/>
        <property name='iplog.contact.name' value='Krzysztof Daniel'/>
        <property name='iplog.contact.email' value='kdaniel@redhat.com'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' version='2.3.5.v201404071733'/>
        <provided namespace='osgi.bundle' name='org.sat4j.pb' version='2.3.5.v201404071733'/>
        <provided namespace='java.package' name='org.sat4j.pb' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints.pb' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.core' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.orders' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.reader' version='2.3.5.v20130525'/>
        <provided namespace='java.package' name='org.sat4j.pb.tools' version='2.3.5.v20130525'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.pb' version='2.3.5.v201404071733'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.pb&#xA;Bundle-Version: 2.3.5.v201404071733
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.tukaani.xz' version='1.5.0.v20170111-1717' singleton='false'>
      <update id='org.tukaani.xz' range='[0.0.0,1.5.0.v20170111-1717)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.bundleVendor' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='XZ for Java'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://tukaani.org/xz/java.html'/>
        <property name='maven-groupId' value='org.eclipse.orbit.bundles'/>
        <property name='maven-artifactId' value='org.tukaani.xz'/>
        <property name='maven-version' value='1.5.0-SNAPSHOT'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.tukaani.xz' version='1.5.0.v20170111-1717'/>
        <provided namespace='osgi.bundle' name='org.tukaani.xz' version='1.5.0.v20170111-1717'/>
        <provided namespace='java.package' name='org.tukaani.xz' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.check' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.common' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.delta' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.index' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.lz' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.lzma' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.rangecoder' version='1.5.0'/>
        <provided namespace='java.package' name='org.tukaani.xz.simple' version='1.5.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='java.package' name='org.tukaani.xz' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.check' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.common' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.delta' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.index' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.lz' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.lzma' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.rangecoder' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.tukaani.xz.simple' range='[1.5.0,2.0.0)' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.tukaani.xz' version='1.5.0.v20170111-1717'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.tukaani.xz&#xA;Bundle-Version: 1.5.0.v20170111-1717
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.4.0.v20161219-1356' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.4.0.v20161219-1356'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.4.0.v20161219-1356'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='1.4.0.v20161219-1356'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' version='1.1.550.v20170928-1359' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='1.1.550.v20170928-1359'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' version='1.1.550.v20170928-1359'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='1.1.550.v20170928-1359'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.rt.osgistarterkit.product.application' version='4.7.1.M20171009-0410'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.application' version='4.7.1.M20171009-0410'/>
      </provides>
      <requires size='21'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.executable.gtk.linux.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.cocoa.macosx.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.4.0.v20161219-1356,1.4.0.v20161219-1356]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.cocoa.macosx.x86_64.rt' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.executable.cocoa.macosx.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64.rt' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.550.v20170928-1359,1.1.550.v20170928-1359]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86.rt' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.1.550.v20170928-1359,1.1.550.v20170928-1359]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.1.550.v20170928-1359,1.1.550.v20170928-1359]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.gtk.linux.x86_64.rt' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.1.550.v20170928-1359,1.1.550.v20170928-1359]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.gtk.linux.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.executable.gtk.linux.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86' range='[1.1.550.v20170928-1359,1.1.550.v20170928-1359]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.gtk.linux.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.gtk.linux.x86.rt' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingorg.eclipse.rt.osgistarterkit.product.config.win32.win32.x86_64' version='4.7.1.M20171009-0410' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.config.win32.win32.x86_64' version='4.7.1.M20171009-0410'/>
        <provided namespace='toolingorg.eclipse.rt.osgistarterkit.product' name='org.eclipse.rt.osgistarterkit.product.config' version='4.7.1.M20171009-0410'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:osgi.noShutdown,propValue:true);setProgramProperty(propName:eclipse.ignoreApp,propValue:true);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:osgi.noShutdown,propValue:);setProgramProperty(propName:eclipse.ignoreApp,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.rt.osgistarterkit.product.configuration' version='4.7.1.M20171009-0410'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.configuration' version='4.7.1.M20171009-0410'/>
      </provides>
      <requires size='30'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.config.gtk.linux.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.p2.console' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.frameworkadmin.equinox' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.config.win32.win32.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator.manipulator' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.common' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.p2.console' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.ini.win32.win32.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.simpleconfigurator.manipulator' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.simpleconfigurator.manipulator' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.p2.console' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.common' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.ini.win32.win32.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.ini.gtk.linux.x86' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.common' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.frameworkadmin.equinox' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.frameworkadmin.equinox' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.frameworkadmin.equinox' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.config.gtk.linux.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.config.win32.win32.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator.manipulator' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.simpleconfigurator.manipulator' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.p2.console' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.frameworkadmin.equinox' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.ini.gtk.linux.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.ini.cocoa.macosx.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.p2.console' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.config.cocoa.macosx.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingorg.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' version='4.7.1.M20171009-0410' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' version='4.7.1.M20171009-0410'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' range='[4.7.1.M20171009-0410,4.7.1.M20171009-0410]'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.rt.osgistarterkit.product.ini.win32.win32.x86_64' version='4.7.1.M20171009-0410' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.rt.osgistarterkit.product.ini.win32.win32.x86_64' version='4.7.1.M20171009-0410'/>
        <provided namespace='toolingorg.eclipse.rt.osgistarterkit.product' name='org.eclipse.rt.osgistarterkit.product.ini' version='4.7.1.M20171009-0410'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            addJvmArg(jvmArg:-Declipse.ignoreApp=true);addProgramArg(programArg:-console);addProgramArg(programArg:-nosplash);addProgramArg(programArg:-consolelog);addProgramArg(programArg:-noexit);
          </instruction>
          <instruction key='unconfigure'>
            removeJvmArg(jvmArg:-Declipse.ignoreApp=true);removeProgramArg(programArg:-console);removeProgramArg(programArg:-nosplash);removeProgramArg(programArg:-consolelog);removeProgramArg(programArg:-noexit);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.common' version='4.7.1.M20171009-0410' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.9.0.v20170207-1454'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' version='4.7.1.M20171009-0410'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.9.0.v20170207-1454'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.frameworkadmin.equinox' version='4.7.1.M20171009-0410' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' range='1.0.800.v20170524-1345'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.frameworkadmin.equinox' version='4.7.1.M20171009-0410'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' range='1.0.800.v20170524-1345'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:3);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.p2.console' version='4.7.1.M20171009-0410' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.console' range='1.0.600.v20170511-1106'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.p2.console' version='4.7.1.M20171009-0410'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.console' range='1.0.600.v20170511-1106'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:3);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator.manipulator' version='4.7.1.M20171009-0410' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='2.0.300.v20170515-0721'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator.manipulator' version='4.7.1.M20171009-0410'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86_64' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='2.0.300.v20170515-0721'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:3);markStarted(started: true);
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='89'>
    <iuProperties id='org.eclipse.rt.osgistarterkit.product' version='4.7.1.M20171009-0410'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rt.osgistarterkit.product.executable.win32.win32.x86_64' version='4.7.1.M20171009-0410'>
      <properties size='1'>
        <property name='unzipped|@artifact|/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt' value='/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt/eclipsec.exe|/opt/public/eclipse/builds/4M/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/equinox.starterkit.product/target/products/org.eclipse.rt.osgistarterkit.product/win32/win32/x86_64/rt/rt.exe|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
